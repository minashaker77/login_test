import 'package:flutter/material.dart';

class InputBox extends StatefulWidget {
  InputBox({required this.hintText, required this.imageIcon});

  final String hintText;
  final Widget imageIcon;

  @override
  _InputBoxState createState() => _InputBoxState();
}

class _InputBoxState extends State<InputBox> {
  TextEditingController  _textController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 50, vertical: 10),
      height: 50,
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(100),
        border: Border.all(color: Colors.grey, width: 1.5),
        image: DecorationImage(
            image: AssetImage('assets/Rectangle1.png'), fit: BoxFit.fill),
      ),
      child: TextField(
        controller: _textController,
        textDirection: TextDirection.ltr,
        textAlign: TextAlign.left,
        cursorColor: Colors.white,
        style:
        TextStyle(color: Colors.white, fontSize: 20, fontFamily: 'Menlo'),
        decoration: InputDecoration(
            prefixIcon: widget.imageIcon,
            hintMaxLines: 1,
            filled: true,
            border: InputBorder.none,
            hintText: widget.hintText,
            hintStyle: TextStyle(
              color: Colors.white,
              fontSize: 20,
            )),
      ),
    );
  }
}